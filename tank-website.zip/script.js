function showAlert() {
    alert("Prepare for battle!");
}
